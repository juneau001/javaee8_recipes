
package org.javaee8recipes.chapter18.recipe18_03;

import java.util.List;
import org.javaee8recipes.entity.BookAuthor;

/**
 *
 * @author Juneau
 */
public interface AuthorInfo {
    
    public List<BookAuthor> authors = null;
    
}
