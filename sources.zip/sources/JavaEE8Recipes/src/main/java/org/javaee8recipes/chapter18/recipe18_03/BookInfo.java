
package org.javaee8recipes.chapter18.recipe18_03;

import java.util.List;
import org.javaee8recipes.entity.Book;

/**
 *
 * @author Juneau
 */
public interface BookInfo {
    
    public List<Book> books = null;
    
}
