
package org.javaee8recipes.chapter13.recipe13_03;

/**
 *
 * @author juneau
 */
public interface Book {
    
    public String title = null;
    public String description = null;
    
}
